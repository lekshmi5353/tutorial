"""Write Python script for converting Binary number into decimal number."""


binary = input("Enter a binary number: ")


decimal = int(binary, 2)


print(f"Decimal representation: {decimal}")