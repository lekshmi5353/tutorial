n = int(input("Enter the value of n: "))

result = 2**(2*n) + n + 5

print(f"Result: {result}")
