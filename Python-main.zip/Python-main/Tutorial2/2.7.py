#Write a Program to converting all lowercase letters into uppercase

s= input(" Enter the string : ")
s=s.upper()

print(s)