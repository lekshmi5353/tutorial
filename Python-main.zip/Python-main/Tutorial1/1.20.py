string = input("Enter a string: ")

if string == string[::-1]:  
    print("The string is a Palindrome.")  
else:  
    print("The string is NOT a Palindrome.")  
